package com.springbootdocker.springbootdocker.dao;

import com.springbootdocker.springbootdocker.model.country;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository("postgres")
public class DataAccessService implements Dao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public DataAccessService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Optional<country> selectCountryByCode(String code) {
        final String sql = "SELECT country.name, country.continent, country.population, country.life_expectancy, country_language.language" +
                " FROM country INNER JOIN country_language ON country.code = country_language.country_code AND country.code = ?";

        country country = jdbcTemplate.queryForObject(sql, new Object[]{code}, (resultSet, i) -> {
                    String name = resultSet.getMetaData().getColumnLabel(1);
                    String continent = resultSet.getMetaData().getColumnLabel(2);
                    Integer population = Integer.valueOf(resultSet.getMetaData().getColumnLabel(3));
                    Float life_expectancy = Float.parseFloat(resultSet.getMetaData().getColumnLabel(4));
                    String language = resultSet.getMetaData().getColumnLabel(5);
            return new country(name,continent,population,life_expectancy,language);
        });
        return Optional.ofNullable(country);
    }
}
