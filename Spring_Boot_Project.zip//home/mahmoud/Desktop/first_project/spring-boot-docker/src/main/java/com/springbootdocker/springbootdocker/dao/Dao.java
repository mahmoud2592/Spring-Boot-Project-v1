package com.springbootdocker.springbootdocker.dao;

import com.springbootdocker.springbootdocker.model.country;

import java.util.Optional;

public interface Dao {

    Optional<country> selectCountryByCode(String code);

}
