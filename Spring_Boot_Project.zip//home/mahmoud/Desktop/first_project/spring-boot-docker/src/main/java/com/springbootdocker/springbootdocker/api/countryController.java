package com.springbootdocker.springbootdocker.api;

import com.springbootdocker.springbootdocker.NotFoundException;
import com.springbootdocker.springbootdocker.model.country;
import com.springbootdocker.springbootdocker.service.countryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("country")
@RestController
public class countryController {

    private final countryService countryService;

    @Autowired
    public countryController(countryService countryService){
        this.countryService = countryService;
    }

    @GetMapping(path = "{code}")
    public country getCountryByCode(@PathVariable("code") String code) throws NotFoundException {
        return countryService.getCountryByCode(code).orElse(null);////////////INVALID_COUNTRY_COD
    }

}
