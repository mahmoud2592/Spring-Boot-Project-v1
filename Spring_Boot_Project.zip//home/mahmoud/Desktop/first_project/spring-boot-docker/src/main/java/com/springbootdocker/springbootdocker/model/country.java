package com.springbootdocker.springbootdocker.model;

import com.fasterxml.jackson.annotation.JsonProperty;



public class country {

    private final String name;
    private final String continent;
    private final Integer population;
    private final Float life_expectancy;

    private final String language;



    public country(@JsonProperty("name")String name,@JsonProperty("continent") String continent,
                   @JsonProperty("population") Integer population, @JsonProperty("life_expectancy") Float life_expectancy, @JsonProperty("language") String language){
        this.name = name;
        this.continent = continent;
        this.population = population;
        this.life_expectancy = life_expectancy;
        this.language = language;
    }

        public String getName(){
            return name;
        }
        public String getContinent(){
            return continent;
        }
        public Integer getPopulation(){
            return population;
        }
        public Float getLife_expectancy() { return life_expectancy; }



        public String getLanguage() {
            return language;
        }
}
