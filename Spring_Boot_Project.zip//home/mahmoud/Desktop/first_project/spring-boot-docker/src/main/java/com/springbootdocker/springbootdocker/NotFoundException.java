package com.springbootdocker.springbootdocker;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "INVALID_COUNTRY_CODE")
public class NotFoundException extends RuntimeException {
}