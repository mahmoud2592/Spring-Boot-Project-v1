package com.springbootdocker.springbootdocker.service;

import com.springbootdocker.springbootdocker.dao.Dao;
import com.springbootdocker.springbootdocker.model.country;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class countryService {

    private final Dao dao;

    public countryService(@Qualifier("Dao") Dao dao){
        this.dao = dao;
    }

    public Optional<country> getCountryByCode(String code){
        return dao.selectCountryByCode(code);
    }

}
